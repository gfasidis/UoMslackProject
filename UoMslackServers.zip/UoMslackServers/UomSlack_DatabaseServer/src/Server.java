import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Server implements Runnable {

	private final static int PORT = 10000;

	ServerSocket serverSocket;
	Socket connection;
	ObjectOutputStream output;
	ObjectInputStream input;
	Statement stmt;
	Connection sqlConnection;
	ResultSet answer;
	int flag;

	public void run() {
		try {
			serverSocket = new ServerSocket(PORT);
			connectToDatabase();
			waitForConnection();
			setupStreams();
			getFlag();
			if (flag == 0)
				writeToDatabase();
			else if (flag == 1)
				readUsers();
			else if (flag == 2)
				readPosts();
			/*else if (flag == 3)
				readDepartments();*/
			else if (flag == 4)
				readCourses();
			else if (flag == 5)
				readSubscriptions();
			else if (flag == 6)
				endConnection();
			else if (flag == 7)
				readFiles();

		} catch (IOException ioException) {
			ioException.printStackTrace();
		} finally {
			endConnection();

		}
	}

	
	private void connectToDatabase() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			sqlConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/uomslackdb", "root", "djjimmys14");
			System.out.println("Connection to database established");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	private void waitForConnection() throws IOException {
		System.out.println("Waiting for connection...");
		connection = serverSocket.accept();
		System.out.println("Received connection from " + connection.getInetAddress().getHostName());
	}

	private void setupStreams() throws IOException {
		output = new ObjectOutputStream(connection.getOutputStream());
		output.flush();
		input = new ObjectInputStream(connection.getInputStream());
		System.out.println("Streams set");
	}

	private void getFlag() throws IOException {
		flag = (int) input.readInt();
		System.out.println("Flag set to " + flag);
	}

	private void readUsers() throws IOException {
		String query;
		String username, password, email, status;
		try {
			query = (String) input.readObject();
			System.out.println("Query read: " + query);
			stmt = sqlConnection.createStatement();
			answer = stmt.executeQuery(query);
			System.out.println("executed");
			while (answer.next()) {
				username = answer.getString(1);
				password = answer.getString(2);
				email = answer.getString(3);
				status = answer.getString(4);
				output.writeObject(username);
				output.flush();
				output.writeObject(password);
				output.flush();
				output.writeObject(email);
				output.flush();
				output.writeObject(status);
				output.flush();
			}
			output.writeObject("stop");
			output.flush();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	private void readPosts() throws IOException {
		String query;
		String courseid, userid, text, date;
		try {
			query = (String) input.readObject();
			System.out.println("Query read: " + query);
			stmt = sqlConnection.createStatement();
			answer = stmt.executeQuery(query);
			System.out.println("executed");
			while (answer.next()) {
				text = answer.getString(1);
				date = answer.getString(2);
				userid = answer.getString(3);
				courseid = answer.getString(4);
				output.writeObject(text);
				output.flush();
				output.writeObject(date);
				output.flush();
				output.writeObject(userid);
				output.flush();
				output.writeObject(courseid);
				output.flush();
			}
			output.writeObject("stop");
			output.flush();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	/*private void readDepartments() throws IOException {
		String query;
		String id, name;
		try {
			query = (String) input.readObject();
			System.out.println("Query read: " + query);
			stmt = sqlConnection.createStatement();
			answer = stmt.executeQuery(query);
			System.out.println("executed");
			while (answer.next()) {
				id = answer.getString(1);
				name = answer.getString(2);
				output.writeObject(id);
				output.flush();
				output.writeObject(name);
				output.flush();

			}
			output.writeObject("stop");
			output.flush();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}*/

	private void readCourses() throws IOException {
		String query;
		String id, title, department, year;
		try {
			query = (String) input.readObject();
			System.out.println("Query read: " + query);
			stmt = sqlConnection.createStatement();
			answer = stmt.executeQuery(query);
			System.out.println("executed");
			while (answer.next()) {
				id = answer.getString(1);
				title = answer.getString(2);
				department = answer.getString(3);
				year = answer.getString(4);
				output.writeObject(id);
				output.flush();
				output.writeObject(title);
				output.flush();
				output.writeObject(department);
				output.flush();
				output.writeObject(year);
				output.flush();
			}
			output.writeObject("stop");
			output.flush();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}
	
	private void readSubscriptions() throws IOException{
		String query;
		String courseid;
		String name;
		try {
			query = (String) input.readObject();
			System.out.println("Query read: " + query);
			stmt = sqlConnection.createStatement();
			answer = stmt.executeQuery(query);
			System.out.println("executed");
			while (answer.next()) {
				name = answer.getString(1);
				courseid = answer.getString(2);
				output.writeObject(name);
				output.flush();
				output.writeObject(courseid);
				output.flush();
			}
			output.writeObject("stop");
			output.flush();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	private void readFiles() throws IOException{
		String query;
		String filename, username, date, courseid;
		try {
			query = (String) input.readObject();
			System.out.println("Query read: " + query);
			stmt = sqlConnection.createStatement();
			answer = stmt.executeQuery(query);
			System.out.println("executed");
			while (answer.next()) {
				filename = answer.getString(1);
				username = answer.getString(2);
				date = answer.getString(3);
				courseid = answer.getString(4);
				output.writeObject(filename);
				output.flush();
				output.writeObject(username);
				output.flush();
				output.writeObject(date);
				output.flush();
				output.writeObject(courseid);
				output.flush();
			}
			output.writeObject("stop");
			output.flush();
		} catch (ClassNotFoundException | SQLException | IOException e) {
			e.printStackTrace();
		}
	}

	private void writeToDatabase() throws IOException {
		String query;
		int rowsAffected;

		try {
			query = (String) input.readObject();
			System.out.println("Query read: " + query);
			stmt = sqlConnection.createStatement();
			rowsAffected = stmt.executeUpdate(query);
			System.out.println("executed");
			output.writeObject("Query successfuly executed. Rows affected: " + rowsAffected);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
			output.writeObject("Something went wrong");
		}
	}

	private void endConnection() {
		try {
			input.close();
			output.close();
			connection.close();
			serverSocket.close();
			System.out.println("Connection Ended");
		} catch (IOException ioException) {
			ioException.printStackTrace();
		}
	}

	public static void main(String args[]) {

		Server server = new Server();
		while (true)
			server.run();

	}

}
