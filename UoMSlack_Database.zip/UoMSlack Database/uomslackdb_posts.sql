-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: uomslackdb
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `text` varchar(250) NOT NULL,
  `date` datetime(6) NOT NULL,
  `username` varchar(30) NOT NULL,
  `courseid` varchar(10) NOT NULL,
  PRIMARY KEY (`text`,`date`,`username`,`courseid`),
  KEY `fk_user_idx` (`username`),
  KEY `fk_course_idx` (`courseid`),
  CONSTRAINT `fk_course` FOREIGN KEY (`courseid`) REFERENCES `courses` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_user` FOREIGN KEY (`username`) REFERENCES `users` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES ('ewrerwerwer','2017-05-22 10:36:39.000000','dai16177','ΠΛ0102-3'),('Just added a new file in this course!\nFile: isPrime(πρώτοι αριθμοί).c','2017-05-22 10:37:19.000000','dai16177','ΠΛ0102-3'),('Just added a new file in this course!\nFile: uomslack','2017-05-22 12:12:12.000000','dai16177','ΠΛ0106-3'),('Just added a new file in this course!\nFile: Χωρίς τίτλο','2017-05-22 12:11:50.000000','dai16177','ΠΛ0106-3'),('Just added a new file in this course!\nFile: autumnfield 2880x1800.jpg','2017-05-22 12:23:02.000000','dai16177','ΠΛ0115'),('Just added a new file in this course!\nFile: Στιγμιότυπο 2017-05-22, 10.59.01','2017-05-22 12:14:18.000000','dai16177','ΠΛ0115'),('Just added a new file in this course!\nFile: Χωρίς τίτλο.rtf','2017-05-22 12:56:59.000000','dai16177','ΠΛ0115'),('Just added a new file in this course!\nFile: uomslack.zip','2017-05-22 14:49:04.000000','dai16177','ΠΛ0304-1'),('Just added a new file in this course!\nFile: Στιγμιότυπο 2017-05-22, 10.59.01','2017-05-22 14:50:47.000000','dai16177','ΠΛ0304-1'),('Just added a new file in this course!\nFile: 12075007_10206050380230807_3350243034347473203_n.jpg','2017-05-31 16:41:29.000000','dai16177','ΠΛ0313-2'),('123','2017-05-21 17:15:13.000000','dai16177','ΠΛ0401'),('a message','2017-05-22 10:09:58.000000','dai16177','ΠΛ0401'),('asjdoijsad','2017-03-31 20:10:12.000000','dai16020','ΠΛ0401'),('cvbcvb','2017-03-31 20:17:33.000000','dai16177','ΠΛ0401'),('dfgdfg','2017-03-31 20:46:18.000000','dai16177','ΠΛ0401'),('erwerwerewrwer','2017-05-24 19:22:49.000000','dai16177','ΠΛ0401'),('fghfghfghfgh','2017-04-02 00:09:09.000000','dai16020','ΠΛ0401'),('fghfghfghhfgh','2017-03-31 20:33:56.000000','dai16177','ΠΛ0401'),('gkljkljkl','2017-04-02 00:09:15.000000','dai16020','ΠΛ0401'),('hhh','2017-03-31 20:39:14.000000','dai16177','ΠΛ0401'),('iopsdf','2017-03-31 20:03:21.000000','dai16020','ΠΛ0401'),('Just added a new file in this course!\nFile: 11371282_509926279159893_179031533_n.jpg','2017-05-22 10:40:19.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: 3pga6e.jpg','2017-05-31 11:28:15.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: emblem.png','2017-05-24 19:22:36.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: gitignore_global.txt','2017-05-21 17:15:22.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: gitignore_global.txt','2017-05-25 13:07:17.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: hello.txt','2017-05-22 13:05:05.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: Kingston 8Gb.jpg','2017-05-22 10:09:37.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: Screenshot_1.jpg','2017-05-21 17:18:06.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: uomslack','2017-05-22 10:40:48.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: uomslack','2017-05-22 11:03:53.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: uomslack','2017-05-22 12:08:12.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: Wine.jpg','2017-05-31 11:16:27.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: Wine.jpg','2017-05-31 11:18:06.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: Wine.jpg','2017-05-31 11:18:11.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: Wine.jpg','2017-05-31 11:18:25.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: Wine.jpg','2017-05-31 11:18:47.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: Στιγμιότυπο 2017-05-22, 10.59.01','2017-05-22 12:16:58.000000','dai16177','ΠΛ0401'),('Just added a new file in this course!\nFile: Χωρίς τίτλο','2017-05-22 14:41:16.000000','dai16177','ΠΛ0401'),('kalhspera','2017-03-31 19:59:19.000000','dai16020','ΠΛ0401'),('mitsos','2017-03-31 20:11:09.000000','dai16020','ΠΛ0401'),('sassadasdasdasdasd','2017-03-31 20:29:54.000000','dai16177','ΠΛ0401'),('sdfsdfsdf','2017-03-31 20:55:20.000000','dai16177','ΠΛ0401'),('suidhfsdfhuishd','2017-03-31 20:25:37.000000','dai16177','ΠΛ0401'),('test','2017-03-31 20:05:05.000000','dai16020','ΠΛ0401'),('test','2017-03-31 20:24:50.000000','dai16177','ΠΛ0401'),('Write something here...','2017-05-25 13:07:10.000000','dai16177','ΠΛ0401'),('τεστ','2017-04-01 23:56:50.000000','dai16020','ΠΛ0401'),('τεστ 2','2017-04-01 23:58:37.000000','dai16020','ΠΛ0401'),('jshdjfhjdkf','2017-05-31 16:54:51.000000','dai16020','ΠΛ0419'),('Just added a new file in this course!\nFile: 01 The Days.mp3','2017-05-31 16:50:58.000000','dai16177','ΠΛ0419'),('Just added a new file in this course!\nFile: 12075007_10206050380230807_3350243034347473203_n.jpg','2017-05-31 16:51:31.000000','dai16177','ΠΛ0419'),('Just added a new file in this course!\nFile: Wine.jpg','2017-05-31 18:50:08.000000','dai16177','ΠΛ0501-1'),('Just added a new file in this course!\nFile: Εργασία 1η','2017-05-22 12:55:38.000000','dai16177','ΠΛ0501-1'),('Just added a new file in this course!\nFile: 1ο παραδοτέο_αναθέσεις.docx','2017-05-22 12:28:27.000000','dai16177','ΠΛ0601');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-02 23:27:58
