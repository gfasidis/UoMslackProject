import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class FileServer implements Runnable {

	// Multi-thread
	private int PORT;
	private static int count = 0;
	private final int firPort = 20000;
	private final static int maxConnections = 10;
	protected Thread runningThread = null;

	private ServerSocket serverSocket;
	private Socket connection;
	private DataInputStream dataInput;
	private DataOutputStream dataOutput;
	private File file;
	private int flag;

	public FileServer() {
		super();
		PORT = firPort + count;
		count++;
	}

	public void run() {

		synchronized (this) {
			this.runningThread = Thread.currentThread();
		}

		try {
			serverSocket = new ServerSocket(PORT);
			waitForConnection();
			setupStreams();
			getFlag();

			if (flag == 0)
				downloadFile();
			else if (flag == 1)
				uploadFile();
			else if (flag == 6)
				endConnection();

			endConnection();
		} catch (IOException e) {
			e.printStackTrace();
		}

		if (count != maxConnections - 1)
			(new Thread(new FileServer())).start();

	}

	private void downloadFile() throws IOException {

		String fileName = dataInput.readUTF();
		FileOutputStream fileOutput = new FileOutputStream("c:/srv/" + fileName);
		byte[] buffer = new byte[4096];

		int filesize = dataInput.readInt();
		int read = 0;
		int totalRead = 0;
		int remaining = filesize;

		while ((read = dataInput.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
			totalRead += read;
			remaining -= read;
			fileOutput.write(buffer, 0, read);
		}

		System.out.println("File " + fileName + " (" + totalRead + " bytes) downloaded");

		fileOutput.close();
		dataInput.close();
	}

	public void uploadFile() throws IOException {

		String fileName = dataInput.readUTF();
		file = new File("c:/srv/" + fileName);
		int fileSize = (int) file.length();

		FileInputStream fileInput = new FileInputStream(file);

		dataOutput.writeInt(fileSize);
		dataOutput.flush();

		byte[] buffer = new byte[4096];

		while (fileInput.read(buffer) > 0)
			dataOutput.write(buffer);

		System.out.println("File " + fileName + " uploaded");

		fileInput.close();
		dataOutput.close();
	}

	private void endConnection() {
		try {
			serverSocket.close();
			connection.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void waitForConnection() throws IOException {
		System.out.println("Waiting for connection...");
		connection = serverSocket.accept();
		System.out.println("Received connection from " + connection.getInetAddress().getHostName());
	}

	private void setupStreams() throws IOException {
		dataOutput = new DataOutputStream(connection.getOutputStream());
		dataOutput.flush();
		dataInput = new DataInputStream(connection.getInputStream());
		System.out.println("Streams set");
	}

	private void getFlag() throws IOException {
		flag = dataInput.readInt();
		System.out.println("Flag set to " + flag);
	}

	public static void main(String args[]) {

		for (int i = 0; i < maxConnections; i++)
			(new Thread(new FileServer())).start();

	}

}
